--  ADMINS (PASSWORDS ARE 444)
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$4KXI.A6nM86RE0iHlFTr5Of522MiApDN74S8pJ/gDdnxX39H336Cu', 'papiqulos', 'admin', 'up1083738@ac.upatras.gr', 6976942344);
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$4KXI.A6nM86RE0iHlFTr5Of522MiApDN74S8pJ/gDdnxX39H336Cu', 'ultron', 'admin', "up1083865@ac.upatras.gr", 6994419907);


-- CITIZENS
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$hZAeJ.dk5V4n11sdUcJtLu5O01NHKp4dBDHJ1PlTAGbiMll4UbRYe', 'user2', 'citizen', 'citizen1@gmail.com', 123556789);
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$hZAeJ.dk5V4n11sdUcJtLu5O01NHKp4dBDHJ1PlTAGbiMll4UbRYe', 'user3', 'citizen', 'citizen2@gmail.com', 123456789);
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$hZAeJ.dk5V4n11sdUcJtLu5O01NHKp4dBDHJ1PlTAGbiMll4UbRYe', 'user4', 'citizen', 'citizen3@gmail.com', 123356789);
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$hZAeJ.dk5V4n11sdUcJtLu5O01NHKp4dBDHJ1PlTAGbiMll4UbRYe', 'user5', 'citizen', 'citizen4@gmail.com', 123256789);
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$hZAeJ.dk5V4n11sdUcJtLu5O01NHKp4dBDHJ1PlTAGbiMll4UbRYe', 'user6', 'citizen', 'citizen5@gmail.com', 123156789);

INSERT INTO Citizen ( name, address, username) VALUES ('citizen2', 'address2', 'user2');
INSERT INTO Citizen ( name, address, username) VALUES ('citizen3', 'address3', 'user3');
INSERT INTO Citizen ( name, address, username) VALUES ('citizen4', 'address4', 'user4');
INSERT INTO Citizen ( name, address, username) VALUES ('citizen5', 'address5', 'user5');
INSERT INTO Citizen ( name, address, username) VALUES ('citizen6', 'address6', 'user6');


-- BUSINESSES (PASSWORDS ARE 111)
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$hZAeJ.dk5V4n11sdUcJtLu5O01NHKp4dBDHJ1PlTAGbiMll4UbRYe', 'busy2', 'business', 'business1@gmail.com', 123556789);
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$hZAeJ.dk5V4n11sdUcJtLu5O01NHKp4dBDHJ1PlTAGbiMll4UbRYe', 'busy3', 'business', 'business2@gmail.com', 163456789);
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$hZAeJ.dk5V4n11sdUcJtLu5O01NHKp4dBDHJ1PlTAGbiMll4UbRYe', 'busy4', 'business', 'business3@gmail.com', 126356789);
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$hZAeJ.dk5V4n11sdUcJtLu5O01NHKp4dBDHJ1PlTAGbiMll4UbRYe', 'busy5', 'business', 'business4@gmail.com', 123256689);
INSERT INTO User ( password, username , role, email, phone_number) VALUES ('$2b$10$hZAeJ.dk5V4n11sdUcJtLu5O01NHKp4dBDHJ1PlTAGbiMll4UbRYe', 'busy6', 'business', 'business5@gmail.com', 123156789);

INSERT INTO Business ( address, name, type, username) VALUES ("addressb1", "businessN1", "type1", "busy2");
INSERT INTO Business ( address, name, type, username) VALUES ("addressb2", "businessN2", "type2", "busy3");
INSERT INTO Business ( address, name, type, username) VALUES ("addressb3", "businessN4", "type3", "busy4");
INSERT INTO Business ( address, name, type, username) VALUES ("addressb4", "businessN5", "type2", "busy5");
INSERT INTO Business ( address, name, type, username) VALUES ("addressb5", "businessN6", "type2", "busy6");


-- DATA SOURCES
INSERT INTO Data_Source (type, location) VALUES ("wifi", "38.2500,21.7300");
INSERT INTO Data_Source (type, location) VALUES ("climate", "38.2450,21.7350");
INSERT INTO Data_Source (type, location) VALUES ("airquaility", "38.2480,21.7320");
INSERT INTO Data_Source (type, location) VALUES ("climate", "38.2470,21.7330");
INSERT INTO Data_Source (type, location) VALUES ("airquaility", "38.2490,21.7310");
INSERT INTO Data_Source (type, location) VALUES ("wifi", "38.2460,21.7340");
INSERT INTO Data_Source (type, location) VALUES ("wifi", "38.2440,21.7360");

-- HAS ACCESS TO DATA SOURCE
-- business_id 1 
INSERT INTO Has_Access (source_id, business_id) VALUES (1, 1);
INSERT INTO Has_Access (source_id, business_id) VALUES (2, 1);
INSERT INTO Has_Access (source_id, business_id) VALUES (3, 1);
INSERT INTO Has_Access (source_id, business_id) VALUES (4, 1);
INSERT INTO Has_Access (source_id, business_id) VALUES (5, 1);
INSERT INTO Has_Access (source_id, business_id) VALUES (6, 1);
INSERT INTO Has_Access (source_id, business_id) VALUES (7, 1);

-- business_id 2 
INSERT INTO Has_Access (source_id, business_id) VALUES (1, 2);
INSERT INTO Has_Access (source_id, business_id) VALUES (6, 2);
INSERT INTO Has_Access (source_id, business_id) VALUES (7, 2);

-- business_id 3 

INSERT INTO Has_Access (source_id, business_id) VALUES (5, 3);
INSERT INTO Has_Access (source_id, business_id) VALUES (6, 3);
INSERT INTO Has_Access (source_id, business_id) VALUES (7, 3);

-- business_id 4 
INSERT INTO Has_Access (source_id, business_id) VALUES (1, 4);
INSERT INTO Has_Access (source_id, business_id) VALUES (2, 4);
INSERT INTO Has_Access (source_id, business_id) VALUES (4, 4);


-- business_id 5 
INSERT INTO Has_Access (source_id, business_id) VALUES (1, 5);
INSERT INTO Has_Access (source_id, business_id) VALUES (2, 5);




--REAL CO2 SENSORS
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.246832515572684,21.735075373001493", "Caravel");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.26054779893219,21.749139490844943", "DOY");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.24701472710519,21.735893329069697", "Public");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.250687644619326,21.732461247139486", "Molos_cafe");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.25248539779457,21.73681497556333", "OMNIA_downtown");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.25113247617404,21.736654894695874", "KTEL");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.248002772343376,21.736358535594338", "ZARA");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.25294744702491,21.74237115169213", "Top_form_gym");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.24506999289779,21.732833395770413", "Dimotiki_Vivliothiki");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.24656701888306,21.735430019476123", "Dimotiko_theatro_Apollon");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.244509238562024,21.73544372605015", "Kafeteria_Teknatzou");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.24719089956328,21.739023600332978", "Sinialo");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.256522878041366,21.742832455346722", "Caravel_2");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.24980647398398,21.738939394396994", "ELTA");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.24509353460653,21.72565858813981", "Faros");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.25611850215096,21.746396128883273", "Coffee_Island");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.259511369737965,21.7491023490339", "Sklavenitis_1");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.24896683529532,21.745332221833255", "Dasilyo");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.26150488840695,21.749518469915984", "Jumbo");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.26344072809693,21.752044240225864", "Arxaiologiko_mouseio");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.268060945979286,21.754903606269682", "Katastima_keramikon");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.270765037338165,21.758447627740498", "NN_double_shot");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.273825902949355,21.75939911193564", "Voi_Noi");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.27576746327301,21.762512384990337", "Sklavenitis_2");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.27850550635471,21.765190927725246", "Xoriatiko");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.281246290079046,21.77023230972924", "Habit_cafe");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.28366827430395,21.77318046545483", "Tofalos");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.287561539541244,21.782468091486272", "Tmima_Oikonomikon_Epistimon");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.28707111626137,21.78290438802524", "Tmima_Dioikisis_Epixeiriseon");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.28618362531044,21.78434595525042", "Tmima_Arxitektonon_Mixanikon");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.284898256944814,21.784332412833127", "Tmima_Theatrikon_Spoudon");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.286077732308264,21.786791429710675", "Prytaneia");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.28708185003933,21.786528412121836", "Parko_Eirinis");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.28832742642908,21.78317494154588", "Tmima_Logotherapeias");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.287876478246794,21.784778487790856", "Mouseio_Epistimon_kai_Texnologias");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.28924101492218,21.78742193926155", "Tmima_Mixanologon_Mixanikon");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.28941997542901,21.7909453303881", "Vivliothiki_Panepistimiou");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.29057133504389,21.78901580952789", "Tmima_Ximikon_Mixanikon");
INSERT INTO Data_Source (type, location, location_n) VALUES ("co2", "38.286121321855966,21.7897330753763", "Foititiki_Estia");


--REAL WIFI SENSORS
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.24922046581489,21.738240952115742", "Plateia_Olgas");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25012735060252,21.739343872945703", "Stroumpio");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25056839070115,21.73849130720503", "11_Dimotiko");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25045148802684,21.74001148806484", "Neo_Dimarxeio");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25198570410572,21.741486050307618", "Konstantinoupoleos_1");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25284718611467,21.741813279393273", "Konstantinoupoleos_2");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25303885990346,21.74190715676657", "Konstantinoupoleos_3");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25375289223751,21.742030537752278", "Konstantinoupoleos_4");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25404355541191,21.742368497165995", "Konstantinoupoleos_5");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.254386876189166,21.74226120727966", "Konstantinoupoleos_6");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25495767013158,21.742722548096115", "Konstantinoupoleos_7");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.255555840431555,21.74295858211148", "Konstantinoupoleos_8");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.256095029682875,21.74291834819285", "Konstantinoupoleos_9");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25675843410173,21.742685847453576", "26_Dimotiko_1");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.256710614994574,21.74287756302452", "26_Dimotiko_2");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25677614453535,21.74306025544198", "Plateia_Nikis_2");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25676020489016,21.74348879397767", "Plateia_Nikis_1");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.25654590259359,21.74315047499239", "Plateia_Voreiou_Ipeirou");


--NEW AP IN HMTY
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.28582328575049,21.790541140972437", "R0_AMF-AP_0.3");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.28611717721533,21.789291613282565", "R0_EST-AP_0.1");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.2861277968144,21.78996374483215", "R0_EST-AP_0.3");
INSERT INTO Data_Source (type, location, location_n) VALUES ("wifi", "38.285532948566974,21.78996373798438", "R0_EST-AP_0.4");

--NEW AIR QUALITY SENSORS IN HMTY
INSERT INTO Data_Source (type, location, location_n) VALUES ("airquality", "38.288275,21.788986", "lab_1"),
INSERT INTO Data_Source (type, location, location_n) VALUES ("airquality", "38.288278,21.788883", "lab_2");


