// When typing in the search bar DOESNT WORK
  // document
  //   .getElementById("origin_input")
  //   .addEventListener("input", autoCompleteOriginDestination(selectionFlag = 0));

  //When the search bar is focused
  // let focusCountOrigin = 0;
  // document
  //   .getElementById("origin_input")
  //   .addEventListener("focus", async function() {
  //   focusCountOrigin++;
  //   console.log("focusCountOrigin", focusCountOrigin);
  //   var results = document.getElementById("results");
  //   results.style.display = "flex";
  //   results.style.flexDirection = "row";
  //   // Get the nearby places accourding to the user's location
  //   //  Only the first time the search bar is focused
  //   if (focusCountOrigin === 1) {
  //     autoCompleteOriginDestination(selectionFlag = 1);
  //   }
  // });

  //When the search bar is unfocused
  // document
  //   .getElementById("origin_input")
  //   .addEventListener("blur", async function() {
  //   console.log("origin blur");
  //   // var results = document.getElementById("results");
  //   // results.style.display = "none";
  // });

  // DESTINATION //
  // When typing in the search bar DOESNT WORK
  // document
  //   .getElementById("destination_input")
  //   .addEventListener("input", autoCompleteOriginDestination(selectionFlag = 0));

  // //When the search bar is focused
  // let focusCountDestination = 0;
  // document
  //   .getElementById("destination_input")
  //   .addEventListener("focus", async function() {
  //   focusCountDestination++;
  //   console.log("focusCountDestination", focusCountDestination);
  //   var results = document.getElementById("results");
  //   results.style.display = "flex";
  //   results.style.flexDirection = "row";
  //   if (focusCountDestination === 1){
  //     autoCompleteOriginDestination(selectionFlag = 1);
  //   };
    
  // });

  // //When the search bar is unfocused
  // document
  //   .getElementById("destination_input")
  //   .addEventListener("blur", async function() {
  //   console.log("destination blur");
  //   // var results = document.getElementById("results");
  //   // results.style.display = "none";
  // });

  // // Listeners for the origin and destination results
  // // When an origin result is clicked
  // document
  //   .getElementById("results-list-origin")
  //   .addEventListener("click", async function(event) {
  //     const target = event.target;
  //     if (target.classList.contains("result")) {
  //       const buttonName = target.textContent;
  //       console.log("origin clicked:", buttonName);
  //       // Select the origin
  //       window.selectedOrigin = buttonName;
  //       // Display the new origin in the input
  //       const originInput = document.getElementById("origin_input");
  //       originInput.value = buttonName;

  //       // Move the pin to the selected origin
  //       const coords = await getCoordsFromPlaceName(buttonName);
  //       originMarker.position = coords;
  //     }
  // });

  // // When a destination result is clicked
  // document
  //   .getElementById("results-list-destination")
  //   .addEventListener("click", async function(event) {
  //     const target = event.target;
  //     if (target.classList.contains("result")) {
  //       const buttonName = target.textContent;
  //       console.log("destination clicked:", buttonName);
  //       // Select the destination
  //       window.selectedDestination = buttonName;
  //       // Display the new destination in the input
  //       const destinationInput = document.getElementById("destination_input");
  //       destinationInput.value = buttonName;

  //       const coords = await getCoordsFromPlaceName(buttonName);
  //       destinationMarker.position = coords;
  //     }
  // });


  // AUTOCOMPLETE SEARCH BAR
async function autoCompleteOriginDestination(selectionFlag = 0) {
  console.log("auto running");
  let selectedOrigins, selectedDestinations;
  const results = document.getElementsByClassName('result');

  // Get the origin and destination input
  const originInput = document.getElementById('origin_input').value;
  const destinationInput = document.getElementById('destination_input').value;

  // Find the origins based on the user input
  if (selectionFlag === 0) {
    selectedOrigins = await textSearchPlace(originInput, 5) || [];
    selectedDestinations = await textSearchPlace(destinationInput, 5) || [];
  }
  else if (selectionFlag === 1) {
    selectedOrigins = await nearbySearchPlace(window.currentLocation, 5) || [];
    selectedDestinations = await nearbySearchPlace(center_bald, 5) || [];
  }
  // Add the results below the input
  selectedOrigins.forEach((place, index) => {
    // console.log("place", place.displayName);
    // console.log("index", index);
    
    const result = results[index];
    // console.log(result.text)
    result.value = index;
    result.textContent = place.displayName;
  });

  // window.selectedOrigin = selectedOrigins[0]; // Default to the first result

  // Add the results below the input
  selectedDestinations.forEach((place, index) => {
    // console.log("place", place.displayName);
    // console.log("index", index);
    
    const result = results[index+5];
    // console.log(result.text)
    result.value = index;
    result.textContent = place.displayName;
  });

  // Store the selected destination
  // window.selectedDestination = selectedDestinations[0]; // Default to the first result

}